CaptnHackSparrow Streaming Web App

1. Install backend dependencies
pip install -r backend/requirements.txt

2. Start backend server
cd backend
uvicorn main:app --reload

3. Open frontend/index.html in browser

NOTE:
Replace frontend/logo.png with your CaptnHackSparrow logo.