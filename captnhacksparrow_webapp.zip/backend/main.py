from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import scraper

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"]
)

@app.get("/movies")
def movies():
    return scraper.get_movies()

@app.get("/search")
def search(q: str):
    return scraper.search_movies(q)

@app.get("/stream")
def stream(url: str):
    return {"video": scraper.get_stream(url)}