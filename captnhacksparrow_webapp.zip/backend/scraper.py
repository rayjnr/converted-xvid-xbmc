import requests
from bs4 import BeautifulSoup

BASE = "https://example.com"

def get_movies():
    r = requests.get(BASE)
    soup = BeautifulSoup(r.text, "html.parser")

    movies = []
    for m in soup.select(".movie"):
        try:
            movies.append({
                "title": m.select_one(".title").text,
                "url": m.select_one("a")["href"],
                "poster": m.select_one("img")["src"]
            })
        except:
            pass

    return movies

def search_movies(query):
    url = f"{BASE}/search?q={query}"
    r = requests.get(url)
    soup = BeautifulSoup(r.text, "html.parser")

    results = []
    for m in soup.select(".movie"):
        try:
            results.append({
                "title": m.select_one(".title").text,
                "url": m.select_one("a")["href"],
                "poster": m.select_one("img")["src"]
            })
        except:
            pass

    return results

def get_stream(url):
    r = requests.get(url)
    soup = BeautifulSoup(r.text, "html.parser")
    src = soup.find("source")
    return src["src"] if src else ""