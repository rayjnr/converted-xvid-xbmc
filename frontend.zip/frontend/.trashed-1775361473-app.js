const API = "http://localhost:8000"

async function loadMovies(){

let r = await fetch(API + "/movies")
let movies = await r.json()

render(movies)
}

function render(list){

let container = document.getElementById("movies")
container.innerHTML = ""

list.forEach(m=>{

let card = document.createElement("div")
card.className="movie"

card.innerHTML=`
<img src="${m.poster}">
<p>${m.title}</p>
`

card.onclick=()=>play(m.url)

container.appendChild(card)

})
}

async function play(url){

let r = await fetch(API + "/stream?url=" + encodeURIComponent(url))
let data = await r.json()

let video = document.getElementById("player")

if(window.Hls && Hls.isSupported() && data.video.includes(".m3u8")){
let hls = new Hls()
hls.loadSource(data.video)
hls.attachMedia(video)
}else{
video.src = data.video
}
}

document.getElementById("search").addEventListener("keyup",async e=>{

let q = e.target.value

if(q.length < 2){
loadMovies()
return
}

let r = await fetch(API + "/search?q=" + q)
let results = await r.json()

render(results)

})

loadMovies()